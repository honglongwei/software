#!/bin/bash
#
#
#

###ServerIP####
IP=`/sbin/ifconfig|egrep -o 'addr:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'|cut -d: -f2|egrep -v '^127|^192'|xargs` 
echo $IP|egrep -q '10.127.' && ServerIP=10.127.2.185
#echo $IP|egrep -q '60.28.211|60.28.206' && ServerIP=10.22.206.147
echo $IP|egrep -q '219.232|124.248' && ServerIP=10.16.224.46
echo $IP|egrep -q '^10.26'  && ServerIP=10.26.2.218
[ $ServerIP ] || ServerIP=180.149.148.75
hostname |egrep -q '\-txy-' && ServerIP=180.149.148.75
hostname |egrep -q '\-jsy-' && ServerIP=118.26.147.191 





###HOSTNAME#####
Hostname=`/sbin/ifconfig|egrep -o 'addr:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'|cut -d: -f2|egrep '^10'`
echo $IP|egrep -q '^10.26' && Hostname=`/sbin/ifconfig|egrep -o 'addr:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'|cut -d: -f2|egrep -v '^127|^192|^10\.'|xargs`

IP=`/sbin/ifconfig|egrep -o 'addr:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'\
|cut -d: -f2|egrep -v '^10\.|^192\.|^127\.'`
NAME=`cat  /etc/.whoami 2>/dev/null`

hostname |egrep -q '\-txy-' && { 

INIIP=`ifconfig eth0|egrep -o 'inet addr:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'|cut -d':' -f2`
NAME=`(cat  /etc/.whoami 2>/dev/null;echo '_txy')|xargs|tr -d ' '`
IP=`awk -v IP=$INIIP '{if($1==IP) print $2}' /etc/iplist`
}

hostname |egrep -q '\-jsy-' && { 

INIIP=`ifconfig eth0|egrep -o 'inet addr:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'|cut -d':' -f2`
NAME=`(cat  /etc/.whoami 2>/dev/null;echo '_jsy')|xargs|tr -d ' '`
IP=`awk -v IP=$INIIP '{if($1==IP) print $2}' /etc/iplist`
}


yum install zabbix zabbix-agent zabbix-sender -y >/dev/null 2>&1 

echo 'ServerActive='$ServerIP >>/etc/zabbix/zabbix_agentd.conf
echo 'Server='$ServerIP >>/etc/zabbix/zabbix_agentd.conf
echo 'Hostname='${NAME}_${IP} >>/etc/zabbix/zabbix_agentd.conf 
#echo 'ListenIP='$Hostname >>/etc/zabbix/zabbix_agentd.conf

#/bin/cat sudoers >>/etc/sudoers 2>/dev/null
mkdir  -p /etc/sudoers.d 
mv zabbix_sudoers /etc/sudoers.d/ 2>/dev/null
rm zabbix.sudoers zabbix_agentd.conf.tgz 2>/dev/null

#sed -i 's/#includedir/includedir/g' /etc/sudoers 
#sh /etc/zabbix/zabbix_scripts/partition_check.sh write
/etc/init.d/zabbix-agent restart
chkconfig zabbix-agent on 
chmod 400 /etc/sudoers.d/*
chown zabbix.root /var/log/messages
chmod +x /home/script

mkdir -p /etc/zabbix/zabbix_scripts/proc_check.d 
mkdir -p /etc/zabbix/zabbix_scripts/dport_check.d
test -d /etc/dport_check.d || ln -s /etc/zabbix/zabbix_scripts/dport_check.d/  /etc/dport_check.d
test -d /etc/proc_check.d || ln -s /etc/zabbix/zabbix_scripts/proc_check.d/ /etc/proc_check.d
cd /etc/zabbix && chown zabbix.zabbix * -R
cd /etc/zabbix/zabbix_scripts/ && chattr -i partition_check.sh && chmod 700 partition_check.sh && chattr +i partition_check.sh 

