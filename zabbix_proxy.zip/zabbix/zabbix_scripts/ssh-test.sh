#!/bin/bash
#
#
#
#

SSHPROC=`ps aux|egrep '/usr/sbin/ssh[d]$'|wc -l`

SSHPORT=`sudo netstat -nltp|grep sshd|awk '{print $4}' |awk -F: '{print $NF}'|sort -u|egrep -v '^22$' |wc -l`


#SSHIP=`sudo /sbin/iptables -nvL INPUT|grep 'dpt:22\b'|egrep  -v  '111.206.12.101|10.127.131.24|220.181.142.28|220.181.143.219|111.206.12.103|10.127.131.26|10.127.65.28'|wc -l`
SSHIP=`sudo /sbin/iptables -nvL INPUT|grep 'dpt:22\b'|egrep  -v  '$@'|wc -l`




#echo SSHPROC=$SSHPROC  SSHPORT=$SSHPORT  IPNAT=$IPNAT SSHIP=$SSHIP

[ $SSHPROC -eq 1 -a $SSHPORT -eq 0 -a $SSHIP -eq 0 ] && echo 1 || echo 0
