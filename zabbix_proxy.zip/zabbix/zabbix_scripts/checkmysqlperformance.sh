#!/bin/sh 
#Create by sfzhang 2014.02.20 
ARGS=2
PORT=$2
#PORT=3309
MYSQL_SOCK="/home/mysql_${PORT}/mysql.sock" 
#if [ $# -ne "$ARGS" ];then 
#    echo "Please input one arguement:" 
#fi 


#discovermysqlport

portarray=`sed -n '/^\[mysqld/,/\[mysqldump\]/p' /etc/my.cnf|grep '^port.*='|tr '\t' ' '|sed -e 's/[ ]*//g'|sort -u|awk -F'=' '{print $2}'|grep '^[1-9]'`

discovery()
{
 
        printf "{ \n" 
        printf "\t\"data\":[ \n"
	NUM=`echo $portarray|xargs -n1|wc -l`
	N=0
        for i in $portarray
        do
    	    let N++
            if [ $N  -lt $NUM ];
            then
                printf "\t\t{ \n" 
                printf "\t\t\t\"{#SITENAME}\":\"${i}\"},\n" 
            else
                printf  "\t\t{ \n"
                printf  "\t\t\t\"{#SITENAME}\":\"${i}\"}]}\n"
            fi
        done
}

QPS()
{
   COMM_SEL1=`mysql -uroot -e "show global status"|grep -i Com_select|awk '{print $2}'`
   sleep 1
   COMM_SEL2=`mysql -uroot -e "show global status"|grep -i Com_select|awk '{print $2}'`
   echo "${COMM_SEL2}"-${COMM_SEL1}|bc -l
}

TPS()
{
   
   mysql -uroot -e "show global status"|egrep -iw "Com_commit|Com_delete|Com_insert|Com_rollback|Com_update">/tmp/tmp_mysql_per1.txt
   sleep 1
   mysql -uroot -e "show global status"|egrep -iw "Com_commit|Com_delete|Com_insert|Com_rollback|Com_update">/tmp/tmp_mysql_per2.txt
   COM_DEL1=`grep Com_delete /tmp/tmp_mysql_per1.txt|awk '{print $2}'`
   COM_INS1=`grep Com_insert /tmp/tmp_mysql_per1.txt|awk '{print $2}'`
   COM_UPD1=`grep Com_update /tmp/tmp_mysql_per1.txt|awk '{print $2}'`
   COM_DEL2=`grep Com_delete /tmp/tmp_mysql_per2.txt|awk '{print $2}'`
   COM_INS2=`grep Com_insert /tmp/tmp_mysql_per2.txt|awk '{print $2}'`
   COM_UPD2=`grep Com_update /tmp/tmp_mysql_per2.txt|awk '{print $2}'`
   echo "(${COM_DEL2}-${COM_DEL1})+(${COM_INS2}-${COM_INS1})+(${COM_UPD2}-${COM_UPD1})"|bc -l
}

case $1 in 
    Discovery)
	    discovery
	;;
    Uptime) 
    	    result=`mysqladmin -uroot -S $MYSQL_SOCK status|cut -f2 -d":"|cut -f1 -d"T"` 
            echo $result 
        ;; 
    Com_update) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK extended-status |grep -w "Com_update"|cut -d"|" -f3` 
        echo $result 
        ;; 
    Slow_queries) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK status |cut -f5 -d":"|cut -f1 -d"O"` 
                echo $result 
                ;; 
    Com_select) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK extended-status |grep -w "Com_select"|cut -d"|" -f3` 
                echo $result 
                ;; 
    Com_rollback) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK extended-status |grep -w "Com_rollback"|cut -d"|" -f3` 
                echo $result 
                ;; 
    Questions) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK status|cut -f4 -d":"|cut -f1 -d"S"` 
                echo $result 
                ;; 
    Com_insert) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK extended-status |grep -w "Com_insert"|cut -d"|" -f3` 
                echo $result 
                ;; 
    Com_delete) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK extended-status |grep -w "Com_delete"|cut -d"|" -f3` 
                echo $result 
                ;; 
    Com_commit) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK extended-status |grep -w "Com_commit"|cut -d"|" -f3` 
                echo $result 
                ;; 
    Bytes_sent) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK extended-status |grep -w "Bytes_sent" |cut -d"|" -f3` 
                echo $result 
                ;; 
    Bytes_received) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK extended-status |grep -w "Bytes_received" |cut -d"|" -f3` 
                echo $result 
                ;; 
    Com_begin) 
        result=`mysqladmin -uroot -S $MYSQL_SOCK extended-status |grep -w "Com_begin"|cut -d"|" -f3` 
                echo $result 
                ;; 
    QPS)
        QPS                
        ;;
    TPS)
        TPS                
        ;;
        *) 
        echo "Usage:$0(Discovery|Uptime|Com_update|Slow_queries|Com_select|Com_rollback|Questions|QPS|TPS)"
        ;; 
esac 
