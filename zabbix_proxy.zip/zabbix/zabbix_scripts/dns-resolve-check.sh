#!/bin/bash
#
#
#20140524
#检测/etc/resole.conf中第一nameserver 是否能解析到domain.txt 多个域名
#解析到一个域名加1。解析不到等0 ，最后计算解析到的总数


cd /etc/zabbix/zabbix_scripts/

mkdir -p log

chown zabbix.zabbix log

DLIST1=`cat domain.txt`

DNSSERVER=`grep ^nameserver /etc/resolv.conf |head -n1|awk '{print $2}'`

s=0

for i in $DLIST1
do  



   n=0
   dig $i > .digtemp

   egrep  "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}|Query" .digtemp \
   |awk '{print $(NF-1),$NF}'|xargs|tr -d 'SERVERA'|tr -d ':'|cut -d'#' -f1|xargs >> log/dig.log

   if ( grep -q $DNSSERVER .digtemp )
   then
        grep -q 'ANSWER: 0' .digtemp  ||  n=1 
   fi

   let s=s+n
done
          
echo $s

