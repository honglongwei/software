#!/bin/bash 
# function:monitor tcp connect status from zabbix 
# 
# xuchangbao


K="[[:blank:]]+"
IP="[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"
PROC="[0-9]{1,5}"

mkdir -p  /etc/zabbix/zabbix_scripts/proc_check.d
> /etc/zabbix/zabbix_scripts/proc_check.d/.all.txt


for i in `cat /etc/proc_check.d/*.conf`
do
    if [[ "$i" =~ (.+):(.+):(.+):(.+) ]]
    then 
        echo $i >> /etc/zabbix/zabbix_scripts/proc_check.d/.all.txt
    fi
done

sort -u  /etc/zabbix/zabbix_scripts/proc_check.d/.all.txt  > /etc/zabbix/zabbix_scripts/proc_check.txt

OP=($(cat /etc/zabbix/zabbix_scripts/proc_check.txt|grep -v "^#" |awk -F: '{print $1}'))
OP1=($(cat /etc/zabbix/zabbix_scripts/proc_check.txt|grep -v "^#"|awk -F: '{print $2}'))
OP2=($(cat /etc/zabbix/zabbix_scripts/proc_check.txt|grep -v "^#"|awk -F: '{print $3}'))
OP3=($(cat /etc/zabbix/zabbix_scripts/proc_check.txt|grep -v "^#"|awk -F: '{print "["$4"]"}'))


[ "$OP1" ] || {
echo \{
echo       \"data\":'[]'
echo \}
exit
}

        printf '{\n' 
        printf '\t"data":[\n' 

for((i=0;i<${#OP[@]};++i)) 
{ 
num=$(echo $((${#OP[@]}-1))) 
        if [ "$i" != ${num} ]; 
                then 
        printf "\t\t{ \n" 
        printf "\t\t\t\"{#PROC}\":\"${OP[$i]}\",\"{#USER}\":\"${OP1[$i]}\",\"{#PATH}\":\"${OP2[$i]}\",\"{#APP}\":\"${OP3[$i]}\"},\n" 
                else 
                        printf  "\t\t{ \n" 
                        printf  "\t\t\t\"{#PROC}\":\"${OP[$num]}\",\"{#USER}\":\"${OP1[$i]}\",\"{#PATH}\":\"${OP2[$i]}\",\"{#APP}\":\"${OP3[$i]}\"}]}\n"
        fi 
}
