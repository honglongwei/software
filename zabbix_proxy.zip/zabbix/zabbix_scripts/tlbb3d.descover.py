#!/usr/bin/python
#coding=utf8
import os,json
r=os.popen("sudo /bin/cat /home/script/monitor/chk_dberr.control 2>/dev/null|grep -iq off  2>/dev/null && exit ||  sudo ls /home/mrdTomcat/game/RuntimeData|egrep '[0-9]{4,6}'|xargs").read().split()
devices=[]
for devpath in r:
        device = os.path.basename(devpath)
        devices+=[{'{#GROUP}':device}]

print json.dumps({'data':devices},sort_keys=True,indent=4,separators=(',',':'))

