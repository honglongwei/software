#!/bin/bash


V=`/usr/sbin/ss -nt state ESTABLISHED|egrep -q '19677|19577' && echo 1 || echo 0`

if [ $V = 0 ]
then
    cd  /home/AxisAgent/ && sh agentctl.sh start >/dev/null  2>&1
    V=`/usr/sbin/ss -nt state ESTABLISHED|egrep -q '19677|19577' && echo 1 || echo 0`
fi

echo $V

