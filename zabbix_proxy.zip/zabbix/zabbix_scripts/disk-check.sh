#!/bin/bash
#
#
#
#
#
#
#

discovery()
{
    WEB_SITE=$(/bin/df |grep [shv]d[a-d]|awk '{print $NF}'|cat -n)
    FARTI=$(/bin/df |grep [shv]d[a-d]|awk '{print NR":"$NF}')
    FARTI_NUM=$(/bin/df |grep [shv]d[a-d]|awk '{print NR":"$NF}'|wc -l)

        printf "{ \n"
        printf "\t\"date\":[ \n"

        for i in $FARTI
        do
            NUM=`echo $i|cut -d':' -f1`
            PAR=`echo $i|cut -d':' -f2`

            if [ $NUM != $FARTI_NUM ];
            then
                printf "\t\t{ \n"
                printf "\t\t\t\"{#SITENAME}\":\"${PAR}\"},\n"
            else
                printf  "\t\t{ \n"
                printf  "\t\t\t\"{#SITENAME}\":\"${PAR}\"}]}\n"
            fi
        done
}



smart_err_num()
{
    for i in `df -h|awk '{print $1}'|egrep -o '[s|h|v]d[a-z]'|sort -u`
    do
        sudo /usr/sbin/smartctl -l error /dev/$i|egrep '^read|^write|^verify'|awk '{print $NF}'|xargs|tr ' ' '+'|bc
    done|xargs|tr ' ' '+'|bc
}


smart_status()
{
/usr/sbin/dmidecode -s system-product-name|egrep -q '410|420' || { echo 100 ; exit ; }
> /tmp/disk.check
if  `/sbin/lspci |grep -qi raid`
then
    sudo /usr/sbin/smartctl -H -d megaraid,0 /dev/sda |egrep   'Status: OK|result: PASSED'  >>/tmp/disk.check
    sudo /usr/sbin/smartctl -H -d megaraid,1 /dev/sda | egrep  'Status: OK|result: PASSED' >>/tmp/disk.check
else

    for i in `df -h|awk '{print $1}'|egrep -o '[s|h|v]d[a-z]'|sort -u`
    do
        sudo /usr/sbin/smartctl -H /dev/$i|egrep  'Status: OK|result: PASSED' >> /tmp/disk.check || { echo 0 ;exit ; }
    done
fi

cat /tmp/disk.check|wc -l
}

case "$1" in
    smart_err_num)
        smart_err_num
        ;;
    smart_status)
        smart_status
        ;;
    discovery)
        
esac
# result: PASSED
