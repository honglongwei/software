#!/bin/bash

HW=`sudo /usr/sbin/dmidecode -s system-product-name|cut -d' ' -f2`

if [ "$HW" == "R710" -o "$HW" == "R410" ]
then
    sudo /usr/bin/ipmitool sdr type "Temperature"| grep Ambient |grep 7.1 |sed -e 's/.*7.1 | \([0-9]\+\).*/\1/'|xargs
fi


if [ "$HW" == "R720" -o "$HW" == "R420" ]
then
    sudo /usr/bin/ipmitool sdr type "Temperature" |grep 7.1 |sed -e 's/.*7.1 | \([0-9]\+\).*/\1/'|sort -u|tail -n1
fi
