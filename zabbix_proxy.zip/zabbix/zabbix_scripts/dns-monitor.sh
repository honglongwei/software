#!/bin/bash


cd /etc/zabbix/zabbix_scripts/
DLIST1=`cat domain.txt`
{ time -p dig $DLIST1  >/dev/null 2>&1 ;  } 2> time1.txt
awk '{print $2}' time1.txt |grep -v dig|xargs|awk '{print ($1+$2+$3)*1000}'




#for i in $DLIST1
#do
#    for d in {1..10}
#    do
#        echo -en "$i "
#        #dig $i |egrep  "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}|Query"|awk '{print $(NF-1),$NF}'|xargs|tr -d 'SERVERA'|tr -d ':'|cut -d'#' -f1|xargs
#        dig $i |egrep  "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}|Query"|awk '{print $(NF-1),$NF}'|xargs|tr -d 'SERVERA'|tr -d ':'|cut -d'#' -f1|xargs
#        #dig $i |egrep  "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}|Query"|awk '{print $(NF-1),$NF}'|xargs|cut -d'#' -f1|tr -d 'SERVERA'
#        #dig $i |egrep  "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}|Query|NMAE"|xargs 
#        #dig $i |egrep  "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}|Query|CNAME"|xargs |awk '{print $14"ms",$1,$10,$18}'|cut -d'#' -f1
#    done
#done
