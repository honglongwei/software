#!/bin/bash
#
#
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
DISK=`df -h|awk '{print $1}'|egrep -o '[s|h|v]d[a-z]'|sort -u|head -n1`
IO3=`/usr/bin/iostat -d $DISK -x 1 10|grep $DISK |awk '{print $12}'|tail -n +2|sed -r 's|(.*)(.)([0-9])([0-9])|\1\2\3|g'|tail -n5|xargs|tr ' ' '+'|bc`
echo $IO3 / 5 |bc
