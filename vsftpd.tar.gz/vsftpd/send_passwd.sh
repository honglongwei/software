db_load -T -t hash -f /etc/vsftpd/account.txt /etc/vsftpd/vsftpd_login.db
