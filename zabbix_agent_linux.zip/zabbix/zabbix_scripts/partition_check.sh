#!/bin/bash

##自动发现 sd hd vd
discovery()
{
    WEB_SITE=$(/bin/df |grep [shv]d[a-d]|awk '{print $NF}'|cat -n)
    FARTI=$(/bin/df |grep [shv]d[a-d]|awk '{print NR":"$NF}')
    FARTI_NUM=$(/bin/df |grep [shv]d[a-d]|awk '{print NR":"$NF}'|wc -l)
 
        printf "{ \n" 
        printf "\t\"date\":[ \n"

        for i in $FARTI
        do
            NUM=`echo $i|cut -d':' -f1`
            PAR=`echo $i|cut -d':' -f2`
    
            if [ $NUM != $FARTI_NUM ];
            then
                printf "\t\t{ \n" 
                printf "\t\t\t\"{#SITENAME}\":\"${PAR}\"},\n" 
            else
                printf  "\t\t{ \n"
                printf  "\t\t\t\"{#SITENAME}\":\"${PAR}\"}]}\n"
            fi
        done
}


#检查磁盘可写
write()
{
    if [ $1 ] ;then 
        cd $1 2>/dev/null && {  
        /bin/echo zabbix_partition_write_test > .zabbix_partition_write_test && echo 1 || echo 0
	} || { echo 0 ; exit ; }
    else
        for i in `/bin/df |grep [shv]d[a-d]|awk '{print $NF}'` ;do
            cd $i && { touch .zabbix_partition_write_test ;  chown zabbix.zabbix .zabbix_partition_write_test ; }
        done

        for i in `/bin/df|tail  -n +2|awk '{print $NF}'|egrep -v 'shm|/dev/mapper'`;do
            cd $i && { touch .zabbix_partition_write_test ; chown zabbix.zabbix .zabbix_partition_write_test ; }
        done
    fi
}

case "$1" in 
discovery) 
    discovery
;; 
write)
    [ $2 ] && write $2
    [ ! $2 ] && write
;; 
*) 
    echo "Usage:$0 {discovery|write[Directory]}" 
;; 
esac 

