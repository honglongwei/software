#!/bin/bash
#
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/root/bin
DISK_NAME=($(df -h|awk '{print $1}'|egrep -o '[s|h|v]d[a-z]'|sort -u))

[ "$DISK_NAME" ] || {
echo \{
echo       \"data\":'[]'
echo \}
exit
}


        printf '{\n' 
        printf '\t"data":[\n' 
for((i=0;i<${#DISK_NAME[@]};++i)) 

{ 
num=$(echo $((${#DISK_NAME[@]}-1))) 
        if [ "$i" != ${num} ]; 
                then 
        printf "\t\t{ \n" 
        printf "\t\t\t\"{#DISK}\":\"${DISK_NAME[$i]}\"},\n" 
                else 
                        printf  "\t\t{ \n" 
                        printf  "\t\t\t\"{#DISK}\":\"${DISK_NAME[$num]}\"}]}\n" 
        fi 
}

