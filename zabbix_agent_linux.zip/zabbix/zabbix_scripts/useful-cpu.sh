#!/bin/bash
#function for qsmy2 CPU monitor 
top -bn 1 |grep Cpu |awk -F':|%' '{print $5}'|cut -d',' -f2|xargs|awk '{printf  ("%f",100-$1) }'
#top -bn 1 |grep Cpu |awk -F':|%' '{print $5}'|cut -d',' -f2|xargs|awk '{print 100-$0 0 0 0 0 0 }' 
