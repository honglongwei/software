#!/bin/bash
MEMTotal=`free |grep Mem |awk '{print $2}'`
MEMuse=`/usr/bin/free |egrep "cache:"|awk '{print $3}'`
PMEMuse=`echo "100*$MEMuse/$MEMTotal"|bc`
#PMEMuse=`echo "scale=2; $MEMuse/$MEMTotal*100"|bc|cut -d'.' -f1`
echo $PMEMuse
