#!/bin/bash
#smart_err_num()
#{
#    for i in `df -h|awk '{print $1}'|egrep -o '[s|h|v]d[a-z]'|sort -u`
#    do
#        sudo /usr/sbin/smartctl -l error /dev/$i|egrep '^read|^write|^verify'|awk '{print $NF}'|xargs|tr ' ' '+'|bc
#    done|xargs|tr ' ' '+'|bc
#}

smart_err_num()
{
A=$RANDOM 
Product=`sudo /usr/sbin/dmidecode -s system-product-name|cut -d' ' -f2`
if [ "$Product" = "2950" -o "$Product" = "R420" -o "$Product" = "R720"  -o "$Product" = "R710" ]
then
    DiskNumber=`sudo /opt/MegaRAID/MegaCli/MegaCli64 -PDList -aAll|egrep 'Slot Number'|awk '{print $NF}'`
    for i in $DiskNumber
    do
        sudo /usr/sbin/smartctl -l error -d megaraid,$i /dev/sda|egrep '^read|^write|^verify'|awk '{print $NF}'|xargs|tr ' ' '+'|bc
    done|xargs|tr ' ' '+'|bc
elif [ "$Product" = "R410" ]
then
    if `/sbin/lspci |grep -qi raid`
    then
	{
        sudo /usr/sbin/smartctl -l error -d megaraid,0 /dev/sda |egrep '^read|^write|^verify'|awk '{print $NF}'|xargs|tr ' ' '+'|bc
        sudo /usr/sbin/smartctl -l error -d megaraid,1 /dev/sda |egrep '^read|^write|^verify'|awk '{print $NF}'|xargs|tr ' ' '+'|bc
	} | xargs|tr ' ' '+'|bc
    else
    	for i in `df -h|awk '{print $1}'|egrep -o '[s|h|v]d[a-z]'|sort -u`
    	do
            sudo /usr/sbin/smartctl -l error /dev/$i|egrep '^read|^write|^verify'|awk '{print $NF}'|xargs|tr ' ' '+'|bc
    	done|xargs|tr ' ' '+'|bc
    fi

else
    echo 100000000; exit

fi
}

non_medium_error()
{
A=$RANDOM 
Product=`sudo /usr/sbin/dmidecode -s system-product-name|cut -d' ' -f2`
if [ "$Product" = "2950" -o "$Product" = "R420" -o "$Product" = "R720"  -o "$Product" = "R710" ]
then
    DiskNumber=`sudo /opt/MegaRAID/MegaCli/MegaCli64 -PDList -aAll|egrep 'Slot Number'|awk '{print $NF}'`
    for i in $DiskNumber
    do
	sudo /usr/sbin/smartctl -l error -d megaraid,$i /dev/sda|grep -i 'Non-medium error count:'|xargs|awk '{print $NF}'
    done|xargs|tr ' ' '+'|bc
elif [ "$Product" = "R410" ]
then
    if `/sbin/lspci |grep -qi raid`
    then
	{
	sudo /usr/sbin/smartctl -l error -d megaraid,0 /dev/sda|grep -i 'Non-medium error count:'|xargs|awk '{print $NF}'
	sudo /usr/sbin/smartctl -l error -d megaraid,1 /dev/sda|grep -i 'Non-medium error count:'|xargs|awk '{print $NF}'
	} | xargs|tr ' ' '+'|bc
    else
    	for i in `df -h|awk '{print $1}'|egrep -o '[s|h|v]d[a-z]'|sort -u`
    	do
	    sudo /usr/sbin/smartctl -l error  /dev/$i|grep -i 'Non-medium error count:'|xargs|awk '{print $NF}'
    	done|xargs|tr ' ' '+'|bc
    fi
else
    echo 100000000; exit
fi
}

smart_status()
{
A=$RANDOM 

>/tmp/disk.check.$A

Product=`sudo /usr/sbin/dmidecode -s system-product-name|cut -d' ' -f2`

if [ "$Product" = "2950" -o "$Product" = "R420" -o "$Product" = "R720"  -o "$Product" = "R710" ]
then
    DiskNumber=`sudo /opt/MegaRAID/MegaCli/MegaCli64 -PDList -aAll|egrep 'Slot Number'|awk '{print $NF}'`
    for i in $DiskNumber
    do
        sudo /usr/sbin/smartctl -H -d megaraid,$i /dev/sda |egrep   'Status: OK|result: PASSED'  >>/tmp/disk.check.$A || { echo 40${i} ; exit ; }
    done
elif [ "$Product" = "R410" ]
then
    if `/sbin/lspci |grep -qi raid`
    then
        sudo /usr/sbin/smartctl -H -d megaraid,0 /dev/sda |egrep  'Status: OK|result: PASSED'  >>/tmp/disk.check.$A || { echo 400 ; exit ; }
        sudo /usr/sbin/smartctl -H -d megaraid,1 /dev/sda |egrep  'Status: OK|result: PASSED'  >>/tmp/disk.check.$A || { echo 401 ; exit ; }
    else
        for i in `df -h|awk '{print $1}'|egrep -o '[s|h|v]d[a-z]'|sort -u`
        do
        sudo  /usr/sbin/smartctl -H /dev/$i|egrep  'Status: OK|result: PASSED' >> /tmp/disk.check.$A || { echo 400 ;exit ; }
        done
    fi

else
    echo 100; exit

fi
cat /tmp/disk.check.$A|wc -l 

}
case "$1" in
    smart_err_num)
        smart_err_num
        ;;
    smart_status)
        smart_status
        ;;
    non_medium_error)
        non_medium_error
        ;;
    *)
     echo 'Usage: /etc/zabbix/zabbix_scripts/disk.sh {smart_err_num | smart_status | non_medium_error} '
       
esac
rm /tmp/disk.check.* 2>/dev/null
# result: PASSE
