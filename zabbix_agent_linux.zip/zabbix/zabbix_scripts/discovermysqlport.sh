#!/bin/bash
portarray=`sed -n '/^\[mysqld/,/\[mysqldump\]/p' /etc/my.cnf|grep '^port.*='|tr '\t' ' '|sed -e 's/[ ]*//g'|sort -u|awk -F'=' '{print $2}'|grep '^[1-9]'`
for PORT in `echo ${portarray}`
do
   echo "MYSQL_PORT:${PORT}"
done
