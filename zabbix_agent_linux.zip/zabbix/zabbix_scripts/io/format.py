#!/usr/bin/python
#coding:utf8
#
#
import os,re

#. ^ $ * + ? {} [] \ | ()

f=open('idrac-temp.txt')
lines=f.readlines()

s='[0-9] .[0-9]'

for i in lines:
    if re.findall(s,i):
        list1=i.strip()
        #list2=(list1.split(' '))
        print list1
f.close()

































#for line in open('/tmp/zabbix_log/log/tj.txt'):
#     ip=(line.split(' ')[0])
#     cpu=",%.1f%s,"%(100 - float(line.split(' ')[1]),"%")
#     mem="%.1f%s,"%((float(line.split(' ')[3]) - float(line.split(' ')[2]) )*100 / float(line.split(' ')[3]),"%")
#     mem_total="%.1f"%float(line.split(' ')[3])
#     list=[ip,cpu,mem,mem_total,"\n"]
#     mubiao.writelines(list
