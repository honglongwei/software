#!/bin/bash

cd /etc/zabbix/zabbix_scripts/io
>io.txt
for i in `cat /tmp/linux_activity_ip.txt`
do
    {
    IOIP=`ssh $i "ipmitool lan print 2>/dev/null|grep 'IP Address' 2>/dev/null |egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'  2>/dev/null"`
    echo -e "$IOIP $i"
    } &

done >>idrac-temp.txt

sleep 300

SSHPID=`ps x|grep 'ssh'|grep 'ipmitool lan prin[t]' 2>/dev/null |awk '{print $1}'|xargs`

[ $SSHPID ] && kill $SSHPID

python format.py > idrac.tx

PORT=443
SSH="ssh -oConnectTimeout=20 -oConnectionAttempts=3"

BJIP="/etc/zabbix/zabbix_scripts/io/bjip"

egrep '^10.127.[0-9]{1,3}\.[0-9]{1,3}' idrac.txt >$BJIP
egrep '^10.110.[0-9]{1,3}\.[0-9]{1,3}' idrac.txt >lfip
egrep '^10.102.[0-9]{1,3}\.[0-9]{1,3}' idrac.txt >tjip
LOG="/var/log/zabbix/idrac_check_`date +%Y%m%d_%H%M`.log"

idrac_check_bj(){
for i in `awk '{print $1}' $BJIP`
do
    {
    IP=`egrep "^$i\b" $BJIP`
    CODE=`/usr/bin/curl -m 30 --retry 5 -k -s -I -o /dev/null -s -w %{http_code} https://$i/login.html 2>/dev/null`
    [ $CODE -ne 200 ] && CODE=`/usr/bin/curl -m 30 --retry 3 -k -s -I -o /dev/null -s -w %{http_code} https://$i 2>/dev/null`
    echo -e "$CODE\t$IP"
    } &
done 
}

LF=219.232.224.46
TJ=60.28.206.147

idrac_check( ){
    scp $IPLIST $CHECK_IP:/tmp/ioip
    $SSH $CHECK_IP '
    for i in `cat /tmp/ioip|cut -f1`
    do  
        {
        IP=`egrep "^$i\b" /tmp/ioip`
        CODE=`/usr/bin/curl -m 30 --retry 3 -k -s -I -o /dev/null -s -w %{http_code} https://$i/login.html 2>/dev/null`
        [ $CODE -ne 200 ] && CODE=`/usr/bin/curl -m 30 --retry 3 -k -s -I -o /dev/null -s -w %{http_code} https://$i 2>/dev/null`
        echo -e "$CODE\t$IP"
        } &
    done
    '
}

# [廊坊iDRAC检查]

CHECK_IP=$LF
IPLIST=lfip

idrac_check >> $LOG

# [天津iDRAC检查]
IPLIST=tjip
CHECK_IP=$TJ
idrac_check >> $LOG

# [北京iDRAC检查] 

idrac_check_bj >> $LOG

wait
awk '$1!=200{print $0}' $LOG >err.log
chown zabbix.zabbix err.log

exit 0
