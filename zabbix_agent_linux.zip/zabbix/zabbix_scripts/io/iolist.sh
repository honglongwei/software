#!/bin/bash
>io.txt

for i in `cat /tmp/linux_activity_ip.txt`
do
    {
    IOIP=`ssh $i "ipmitool lan print 2>/dev/null|grep 'IP Address' 2>/dev/null |egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'  2>/dev/null"`
    echo -e "$IOIP $i"
    } &

done | sed 's/^ //g'  >>io.txt
