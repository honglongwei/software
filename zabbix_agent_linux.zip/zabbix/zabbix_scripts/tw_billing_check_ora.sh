#!/bin/bash
#check alert.log for ORA error

#wdate=`date -d "500 minutes ago" +%b" "%d" "%H`
wdate=`date +%b" "%d" "%H`

BASEDIR=/home/oracle/dbadmin
export ORACLE_BASE=/U01/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/11.2.3/db_1
export ORACLE_SID=billdb
export PATH=$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$ORACLE_HOME/jdk/bin:$PATH
export LANG="en_US.UTF-8"
export NLS_LANG=american_AMERICA.UTF8
export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"
export TNS_ADMIN="/U01/app/oracle/product/11.2.3/db_1/network/admin"
alert_log=$ORACLE_BASE/diag/rdbms/billdb/billdb/trace/alert_billdb.log

cnt=`sudo grep -n -A 10000 "$wdate" $alert_log|sudo grep -c ORA-`

if [ $cnt -ne 0 ]
then
 echo 0
else
 echo 1
fi
