#!/bin/bash
[ ! -s /etc/zabbix/zabbix_scripts/io/err.log ] && echo  "0"
/bin/awk '{print "连接ILO失败,请检查 ILOIP="$2,"外网IP="$3,"SN="$NF}' /etc/zabbix/zabbix_scripts/io/err.log
