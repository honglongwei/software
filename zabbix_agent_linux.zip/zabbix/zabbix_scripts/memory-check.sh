#!/bin/bash

A=$RANDOM 

sudo ipmitool sel list|grep ECC >/tmp/mem.$A

grep -iq Error /tmp/mem.$A && echo 0 || echo 1

rm /tmp/mem.$A


