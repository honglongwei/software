#!/bin/bash
#
#xuchangbao Written in 20140623
#
#find / -path '/proc*' -a -prune -o  \( -name *.php -o -name *.jsp \) >/tmp/webshell_check.txt
#webshell_check(){
#egrep -i -3 'getRuntime\|k8cmd\|JFolder\|shell\|String Pwd=\|FileOutputStream\|OutputStreamWriter\|xiangxilianjie\|create proc\|n1nty\|String PW =\|JspSpy\|hack520\|jmmm.com\|piped\|remoteHost\|/bin/sh\|cmd\|command\|JythonShell\|JspWebshell\|file.exists\|f.exists\|getRealPath\|upload|ServletInputStream\|ServletOutputStream\|JFileMan\|driver.OracleDriver\|jdbc.Driver\|executeQuery\|management\|muma\|backdoor' $1 
#}

cd /etc/zabbix/zabbix_scripts/scan

for i in `locate *.php`;do  dirname $i ; done|sort -u >scan.txt

for i in `cat scan.txt`
do
     echo $i-------------------------------------
     perl /etc/zabbix/zabbix_scripts/scan/ScanWebShell.pl $i 1
     echo 
 
done
