#!/bin/bash 
# function:monitor tcp connect status from zabbix 
# 
# xuchangbao


K="[[:blank:]]+"
IP="[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"
PROC="[0-9]{1,5}"

/usr/bin/mkdir -p  /cygdrive/c/zabbix/zabbix_scripts/proc_check.d


OP=($(/usr/bin/cat /cygdrive/c/zabbix/zabbix_scripts/proc_check.d/proc_check.txt|/usr/bin/grep -v "^#" |/usr/bin/awk -F: '{print $1}'))
OP1=($(/usr/bin/cat /cygdrive/c/zabbix/zabbix_scripts/proc_check.d/proc_check.txt|/usr/bin/grep -v "^#"|/usr/bin/awk -F: '{print $2}'))


[ "$OP1" ] || {
echo \{
echo       \"data\":'[]'
echo \}
exit
}

        printf '{\n' 
        printf '\t"data":[\n' 

for((i=0;i<${#OP[@]};++i)) 
{ 
num=$(echo $((${#OP[@]}-1))) 
        if [ "$i" != ${num} ]; 
                then 
        printf "\t\t{ \n" 
        printf "\t\t\t\"{#PROC}\":\"${OP[$i]}\",\"{#NUM}\":\"${OP1[$i]}\"},\n" 
                else 
                        printf  "\t\t{ \n" 
                        printf  "\t\t\t\"{#PROC}\":\"${OP[$num]}\",\"{#NUM}\":\"${OP1[$i]}\"}]}\n"
        fi 
}
