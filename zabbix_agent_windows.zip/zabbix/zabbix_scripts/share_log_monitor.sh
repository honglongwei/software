#!/bin/bash
date=`/usr/bin/date +%Y%m%d%H`
LPATH=`/usr/bin/ls -l /cygdrive/d/xj5/ |/usr/bin/awk '{print $9}'|/usr/bin/grep xj5|/usr/bin/sed 's/ //g'`
cd  /cygdrive/d/xj5/$LPATH/Log/
filename=`/usr/bin/ls |/usr/bin/grep $date|/usr/bin/grep Share`
/usr/bin/grep "Microsoft OLE DB Provider for SQL Server" $filename >/dev/null
if [  $? == 0  ];then
      echo 1
else
      echo 0
fi

