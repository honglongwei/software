#!/bin/bash
proc_name=`/cygdrive/c/Windows/system32/tasklist |/usr/bin/grep -w $1 |/usr/bin/awk '{print $1}' |/usr/bin/sort |/usr/bin/uniq`
proc_num=`/cygdrive/c/Windows/system32/tasklist |/usr/bin/grep -w $1 |/usr/bin/wc -l`
if [ -n "$proc_name"  -a  "$proc_num" == $2 ];then
	echo 0
elif [ -n "$proc_name" -a "$proc_num" != $2 ];then
	echo 1
else 
        echo 2
fi
