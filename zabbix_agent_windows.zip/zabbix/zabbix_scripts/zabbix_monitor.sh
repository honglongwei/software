#!/cygdrive/c/cygwin/bin/bash.exe 
#
#xuchangbao write in 20140703
#

export PATH=/usr/local/bin:/usr/bin:/cygdrive/c/windows/system32:/cygdrive/c/windows\
:/cygdrive/c/windows/System32/Wbem:/cygdrive/c/windows/System32/WindowsPowerShell/v1.0


cpu_utilization() {
wmic cpu get loadpercentage,SocketDesignation|grep $1|awk '{print $1}'
}

disk_smart_err_num(){
    /cygdrive/c/Program\ Files\ \(x86\)/smartmontools/bin/smartctl.exe \
    -a /dev/sda|grep "^[read|write|verify]"|awk '{print $1 $NF}'|awk 'BEGIN{sum=0}{sum+=$NF}END{print sum}'
}

disk_smart_status(){
    /cygdrive/c/Program\ Files\ \(x86\)/smartmontools/bin/smartctl.exe \
    -H /dev/sda|grep -q 'Status: OK' && echo 1 || echo 0
    
}

disk_write(){
    echo `date` > /cygdrive/${1}/disk_write.test && echo 1 || echo 0
} 

ambient_temp(){
    wmic csproduct get name|grep -q R410 &&  ID=000a
    wmic csproduct get name|grep -q R420 &&  ID=0017
    /cygdrive/c/tools/ipmi64/ipmiutil.exe  sensor -i $ID |grep degrees|awk '{print $(NF-2)}'|cut -d'.' -f1
}


case "$1" in
  cpu_utilization)
        cpu_utilization CPU.*$2
        ;;
  disk_smart_status)
  	disk_smart_status
        ;;
  disk_smart_err)
  	disk_smart_err_num
        ;;
  disk_write)
	disk_write $2 2>/dev/null
	;;
  ambient_temp)
  	ambient_temp
        ;;
  *)
        echo $"Usage: $0 {cpu_utilization|disk_smart_status|disk_smart_err|ambient_temp|disk_write}"
        exit 1
esac
