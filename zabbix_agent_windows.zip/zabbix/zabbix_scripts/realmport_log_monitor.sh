#!/bin/bash
date=`/usr/bin/date +%Y%m%d%H`
LPATH=`/usr/bin/ls -l /cygdrive/d/xj5/ |/usr/bin/awk '{print $9}'|/usr/bin/grep xj5|/usr/bin/sed 's/ //g'`
cd  /cygdrive/d/xj5/$LPATH/Log/
filename=`/usr/bin/ls |/usr/bin/grep $date|/usr/bin/grep DBApp`
/usr/bin/grep "realmport  no item config playerId="  $filename >/dev/null
if [ $? == 0 ];then
      a=1
else 
      a=0
fi
/usr/bin/grep "call DBRealPortChargeOrderNtf failed order_id" $filename >/dev/null
if [ $? == 0 ];then 
      b=1
else  
      b=0
fi
/usr/bin/grep "cid error Gm" $filename >/dev/null
if [ $? == 0 ];then  
      c=1
else   
      c=0
fi
/usr/bin/grep "item_id error Gm" $filename >/dev/null
if [ $? == 0 ];then  
      d=1
else   
      d=0
fi
/usr/bin/grep "count error Gm" $filename >/dev/null
if [ $? == 0 ];then  
      e=1
else  
      e=0
fi
/usr/bin/grep "order_id  error Gm" $filename >/dev/null
if [ $? == 0 ];then 
      f=1
else   
      f=0
fi
/usr/bin/grep "channel error Gm" $filename >/dev/null
if [ $? == 0 ];then 
      g=1
else   
      g=0
fi
/usr/bin/grep "reader.parse failed Gm" $filename >/dev/null
if [ $? == 0 ];then 
      h=1
else   
      h=0
fi
if [ ${a} -eq 0 -a ${b} -eq 0 -a ${c} -eq 0 -a ${d}  -eq 0 -a ${e} -eq 0 -a ${f} -eq 0 -a ${g} -eq 0 -a ${h} -eq 0 ];then
     echo 0
else 
     echo 1
fi
