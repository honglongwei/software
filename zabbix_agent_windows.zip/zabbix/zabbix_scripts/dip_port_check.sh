#!/bin/bash 
# function:monitor tcp connect status from zabbix 
# 
# xuchangbao


#source /etc/bash.bashrc>/dev/null 2>&1 
#source /etc/profile  >/dev/null 2>&1 

#/usr/bin/curl -o /dev/null -s -w %{http_code} http://$1/ 
WEB_SITE_discovery () { 
WEB_SITE=($(/cygdrive/c/cygwin/bin/cat.exe /cygdrive/c/zabbix/zabbix_scripts/dip_port_check.txt|/cygdrive/c/cygwin/bin/grep.exe -v "^#" |/cygdrive/c/cygwin/bin/awk -F: '{print $1}')) 
WEB_SITE1=($(/cygdrive/c/cygwin/bin/cat.exe /cygdrive/c/zabbix/zabbix_scripts/dip_port_check.txt|/cygdrive/c/cygwin/bin/grep.exe -v "^#"|/cygdrive/c/cygwin/bin/awk -F: '{print $2}')) 
WEB_SITE2=($(/cygdrive/c/cygwin/bin/cat.exe  /cygdrive/c/zabbix/zabbix_scripts/dip_port_check.txt|/cygdrive/c/cygwin/bin/grep.exe -v "^#"|/cygdrive/c/cygwin/bin/awk -F: '{print $3}')) 

[ "$WEB_SITE" ] || {
echo \{
echo       \"data\":'[]'
echo \}
exit
}



        printf '{\n' 
        printf '\t"data":[\n' 
for((i=0;i<${#WEB_SITE[@]};++i)) 

{ 
num=$(echo $((${#WEB_SITE[@]}-1))) 
        if [ "$i" != ${num} ]; 
                then 
        printf "\t\t{ \n" 
        #printf "\t\t\t\"{#SITENAME}\":\"${WEB_SITE[$i]}\"},\n" 
        printf "\t\t\t\"{#IP}\":\"${WEB_SITE[$i]}\",\"{#PORT}\":\"${WEB_SITE1[$i]}\",\"{#APP}\":\"${WEB_SITE2[$i]}\"},\n" 
                else 
                        printf  "\t\t{ \n" 
                        printf  "\t\t\t\"{#IP}\":\"${WEB_SITE[$num]}\",\"{#PORT}\":\"${WEB_SITE1[$i]}\",\"{#APP}\":\"${WEB_SITE2[$i]}\"}]}\n" 
        fi 
} 
} 

case "$1" in 
web_site_discovery) 
WEB_SITE_discovery 
;; 
web_site_code) 
web_site_code $2 
;; 
*) 
echo "Usage:$0 {web_site_discovery|web_site_code [URL]}" 
;; 
esac 
