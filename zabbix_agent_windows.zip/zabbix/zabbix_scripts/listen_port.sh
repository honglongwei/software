#!/bin/bash 
# function:monitor tcp connect status from zabbix 
# 
# wangjiale



#source /etc/bash.bashrc>/dev/null 2>&1 
#source /etc/profile  >/dev/null 2>&1 

#/usr/bin/curl -o /dev/null -s -w %{http_code} http://$1/ 
Port_discovery () {
	port=($(/cygdrive/c/cygwin/bin/cat.exe /cygdrive/c/zabbix/zabbix_scripts/listen_port.txt|/cygdrive/c/cygwin/bin/grep.exe -v "^#"))

[ "$port" ] || {
echo \{
echo       \"data\":'[]'
echo \}
exit
}
  printf '{\n'
  printf '\t"data":[\n'
for((i=0;i<${#port[@]};++i))
{
num=$(echo $((${#port[@]}-1)))
if [ "$i" != ${num} ];
then
  printf "\t\t{ \n"
  printf "\t\t\t\"{#PORT}\":\"${port[$i]}\"},\n" 
else
  printf  "\t\t{ \n"
  printf  "\t\t\t\"{#PORT}\":\"${port[$num]}\"}]}\n"
fi
}
}

Port_discovery
