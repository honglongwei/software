#!/bin/bash
date=`/usr/bin/date +%Y%m%d%H`
LPATH=`/usr/bin/ls -l /cygdrive/d/xj5/ |/usr/bin/awk '{print $9}'|/usr/bin/grep xj5|/usr/bin/sed 's/ //g'`
cd  /cygdrive/d/xj5/$LPATH/Log/
filename=`/usr/bin/ls |/usr/bin/grep $date|/usr/bin/grep DBApp`
/usr/bin/grep "IsOnce chargeInfo.item_count > 1 order_id"  $filename >/dev/null
if [ $? == 0 ];then
      connect=1
else 
      connect=0
fi
/usr/bin/grep "giveMb <1 order_id" $filename >/dev/null
if [ $? == 0 ];then 
      Meaning=1
else  
      Meaning=0
fi
if [ ${connect} == 0  -a ${Meaning} == 0 ];then
      echo 0
else 
      echo 1
fi
