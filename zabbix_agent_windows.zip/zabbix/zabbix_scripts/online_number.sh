#!/bin/bash
zuhao="3066"
tim=`/usr/bin/date +%Y-%m-%d-%H`
cd /cygdrive/d/xj5/xj5_${zuhao}/Log/${zuhao}00001/cylog/
num=`/usr/bin/awk '{print $NF}' heart.log.${tim}|/usr/bin/awk -F"\001" '{print $8}'`
/usr/bin/echo ${num}
