#!/bin/bash
date=`/usr/bin/date +%Y%m%d%H`
LPATH=`/usr/bin/ls -l /cygdrive/d/xj5/ |/usr/bin/awk '{print $9}'|/usr/bin/grep xj5|/usr/bin/sed 's/ //g'`
cd  /cygdrive/d/xj5/$LPATH/Log/
filename=`/usr/bin/ls |/usr/bin/grep $date|/usr/bin/grep LGW`
fnum=`/usr/bin/grep "call ProcessLoginData failed iRet" $filename|/usr/bin/awk '{print $NF}'|/usr/bin/awk -F"=" '{print $2}'|/usr/bin/sort|/usr/bin/uniq -c|/usr/bin/grep 204|/usr/bin/awk '{print $1}'`
snum=`/usr/bin/grep "call ProcessLoginData failed iRet"  $filename |/usr/bin/awk '{print $NF}'|/usr/bin/awk -F"=" '{print $2}' |/usr/bin/sort |/usr/bin/uniq -c |/usr/bin/grep 207|/usr/bin/awk '{print $1}'`
mnum=`/usr/bin/grep "call ProcessLoginData failed iRet"  $filename |/usr/bin/awk '{print $NF}'|/usr/bin/awk -F"=" '{print $2}' |/usr/bin/sort |/usr/bin/uniq -c |/usr/bin/grep 206|/usr/bin/awk '{print $1}'`
nnum=`/usr/bin/grep "call ProcessLoginData failed iRet"  $filename |/usr/bin/awk '{print $NF}'|/usr/bin/awk -F"=" '{print $2}' |/usr/bin/sort |/usr/bin/uniq -c |/usr/bin/grep 214|/usr/bin/awk '{print $1}'`
if [  $fnum  ];then
      if [ $fnum -gt 50 ];then
           fflag=1
      else
           fflag=0
      fi
else
           fflag=0
fi
if [  $snum ];then 
      if [  $snum -gt 50 ];then
           sflag=1
      else
           sflag=0
      fi
else
           sflag=0
fi
if [  $mnum ];then
      if [  $mnum -gt 50 ];then
           mflag=1
      else
           mflag=0
      fi
else
           mflag=0
fi
if [  $nnum ];then
      if [  $nnum -gt 50 ];then
           nflag=1
      else
           nflag=0
      fi
else
           nflag=0
fi
if [ $fflag = 1 -o $sflag = 1 -o $mflag = 1 -o $nflag = 1 ];then
      echo 1
else
      echo 0
fi

