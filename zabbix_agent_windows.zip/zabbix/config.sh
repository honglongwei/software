#!/cygdrive/c/cygwin/bin/bash.exe 
#
#xuchangbao write in 20140703
#

export PATH=/usr/local/bin:/usr/bin:/cygdrive/c/windows/system32:/cygdrive/c/windows\
:/cygdrive/c/windows/System32/Wbem:/cygdrive/c/windows/System32/WindowsPowerShell/v1.0



ServerIP=10.253.24.130


###HOSTNAME#####
#Hostname=` ipconfig|grep -i IPv4|egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'|egrep -v '^10\.|^255|254$'`



echo 'ServerActive='$ServerIP >>/cygdrive/c/zabbix/conf/zabbix_agentd.win.conf
echo 'Server='$ServerIP >>/cygdrive/c/zabbix/conf/zabbix_agentd.win.conf
echo 'Hostname='${1}_windows_${2} >>/cygdrive/c/zabbix/conf/zabbix_agentd.win.conf

/cygdrive/c/zabbix/bin/win64/zabbix_agentd.exe -c c:/zabbix/conf/zabbix_agentd.win.conf -i
/cygdrive/c/zabbix/bin/win64/zabbix_agentd.exe -c c:/zabbix/conf/zabbix_agentd.win.conf -s
netstat -ant |grep 10050
