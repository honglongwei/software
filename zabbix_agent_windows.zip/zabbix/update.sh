#!/bin/bash
#
#
#
###ServerIP####
IP=`ipconfig|egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'|xargs`
echo $IP|egrep -q '10.127.' && ServerIP=10.127.2.185
echo $IP|egrep -q '60.28.211|60.28.206' && ServerIP=10.22.206.147
echo $IP|egrep -q '219.232|124.248' && ServerIP=10.16.224.46

###HOSTNAME#####
Hostname=`ipconfig|egrep -o '10.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'`

echo 'ServerActive='$ServerIP >>/cygdrive/c/zabbix/conf/zabbix_agentd.win.conf
echo 'Server='$ServerIP >>/cygdrive/c/zabbix/conf/zabbix_agentd.win.conf
echo 'Hostname='$Hostname >>/cygdrive/c/zabbix/conf/zabbix_agentd.win.conf
echo 'ListenIP='$Hostname >>/cygdrive/c/zabbix/conf/zabbix_agentd.win.conf

/cygdrive/c/zabbix/bin/win64/zabbix_agentd.exe -c c:/zabbix/conf/zabbix_agentd.win.conf -i
/cygdrive/c/zabbix/bin/win64/zabbix_agentd.exe -c c:/zabbix/conf/zabbix_agentd.win.conf -s
netstat -ant |grep 10050
