#!/bin/bash
PORT=`ps axu|grep './Server -worldi[d]'|xargs -l|awk '{print $NF}'`

[ $PORT ] || { echo 0 ; exit ; }

case "$1" in
        Player)
		sudo /bin/awk  -F:  /'^Player:'/'{print $2}'  \
		/home/mrdTomcat/game/RuntimeData/$PORT/Log/Pool.`date +%F-%H`.log|tail -n1
                ;;
        ValidateAccountMsg)
		sudo /bin/awk -F:  /'^ValidateAccountMsg:'/'{print $2}' \
		/home/mrdTomcat/game/RuntimeData/$PORT/Log/Pool.`date +%F-%H`.log|tail -n1
                ;;
        RunSlowly)
		sudo /bin/grep 'Run Slowly, Invoker(DBServiceExecInvoker' \
		/home/mrdTomcat/game/RuntimeData/$PORT/Log/Efficiency.`date +%F-%H`.log| \
		tail -n1|awk '{print $4}'|tr '()' ' '|cut -d' ' -f2
		;;
        *)
                echo $"Usage: $0 {Player|ValidateAccountMsg|RunSlowly}"
                
esac

