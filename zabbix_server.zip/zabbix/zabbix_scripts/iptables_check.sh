#!/bin/bash
#
K="[[:blank:]]*"
STATUSB=`sudo /sbin/iptables -nvL INPUT |grep  -q 'INPUT (policy ACCEPT' && echo 0  || echo 1`

[ $STATUSB -eq 1 ] && { echo 1 ; exit   ; } 

STATUSA=`sudo /sbin/iptables -nvL INPUT |tail -n2|egrep "[DROP|REJECT]${K}all${K}--${K}(eth0|em1|eth1|em2|\*)${K}\*${K}0.0.0.0/0${K}0.0.0.0/0"|wc -l|awk '{if($0==2){print 1}else{print 0}}'`
[ $STATUSA -eq 1 -o $STATUSB -eq 1 ] && echo 1 || echo 0
