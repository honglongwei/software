#!/bin/bash
#
#

MegaCli=/opt/MegaRAID/MegaCli/MegaCli64


case "$1" in
    Other.Error.Count)
        sudo  $MegaCli -CfgDsply -aALL -NoLog |egrep -i 'Other Error Count:'|awk '{num+=$NF}END{print num}'  
        ;;
    Media.Error.Count)
        sudo $MegaCli -CfgDsply -aALL -NoLog |egrep -i 'Media Error Count:'|awk '{num+=$NF}END{print num}'
   	    ;;
    Disk.Max.Temp)
        sudo $MegaCli -PDList -aAll|grep Temperature|sed -r 's/(.*:)([0-9]{1,3})(C.*)/\2/g'|sort -n|tail -n1
        ;;
    templ)
        sudo $MegaCli -PDList -aAll|grep Temperature|sed -r 's/(.*:)([0-9]{1,3})(C.*)/\2/g'|sort -n|head -n1    
        ;;
    LD.State)
        sudo $MegaCli -LDInfo -Lall -aALL |grep State|awk '{print $NF}'
        ;;
    Firmware.Up.Num)
        sudo $MegaCli -PDList -aALL -NoLog|grep 'Firmware state' |grep 'Spun Up'|wc -l
        ;;
    Disk.Failed.Num)
        sudo $MegaCli -AdpAllInfo -aALL|grep 'Failed Disks'|awk '{print $NF}'
        ;;
    Remaining.Capacity.Low)
       sudo $MegaCli -AdpBbuCmd -GetBbuStatus -aALL|grep 'Remaining Capacity Low'|awk -F: '{print $NF}'|xargs
        ;;
    Charger.Status)
        sudo $MegaCli -AdpBbuCmd -GetBbuStatus -aALL|grep 'Charger Status'|awk '{print $NF}'
        ;;
    Default.Cache.Policy)
        sudo $MegaCli -LDInfo -Lall -aALL |grep  'Default Cache Policy'|egrep -o 'WriteThrough|WriteBack'|sort -u
        ;;
    Current.Cache.Policy)
        sudo $MegaCli -LDInfo -Lall -aALL |grep  'Current Cache Policy'|egrep -o 'WriteThrough|WriteBack'|sort -u 
        ;;
    Disk.Num)
        sudo $MegaCli -PDGetNum -aALL -NoLog |grep Adapter|awk '{print $NF}'
        ;;
    IO.Scheduler)
        egrep -o "\[.*\]" /sys/block/sda/queue/scheduler|tr -d '[]'
        ;;
    *)
        echo $ "Usage: $0 {Other.Error.Count|Media.Error.Count|Disk.Max.Temp|LD.State|Firmware.Up.Num|Disk.Failed.Num|Remaining.Capacity.Low|Charger.Status|Default.Cache.Policy|Current.Cache.Policy|Disk.Num|IO.Scheduler}"
esac
