#!/usr/bin/python
#coding=utf8
import os,json

r=open('/etc/zabbix/zabbix_scripts/listen_port.txt','r').read().split()

devices=[]
for devpath in r:
    device = os.path.basename(devpath)
    devices+=[{'{#SITENAME}':device}]

print json.dumps({'data':devices},sort_keys=True,indent=7,separators=(',',':'))
