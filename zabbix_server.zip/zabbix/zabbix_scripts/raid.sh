#!/bin/bash
#
#
if [ -f /opt/MegaRAID/MegaCli/MegaCli64 ]
then
    ln -sf /opt/MegaRAID/MegaCli/MegaCli64 /opt/MegaRAID/MegaCli/MegaCli >/dev/null 2>&1
    ln -sf /opt/MegaRAID/MegaCli/MegaCli64 /bin/MegaCli >/dev/null 2>&1
    ln -sf /opt/MegaRAID/MegaCli/MegaCli64 /bin/megacli >/dev/null 2>&1
fi

if [ -f /opt/MegaRAID/MegaCli/MegaCli ]
then
    ln -sf /opt/MegaRAID/MegaCli/MegaCli /bin/MegaCli >/dev/null 2>&1
    ln -sf /opt/MegaRAID/MegaCli/MegaCli /bin/megacli >/dev/null 2>&1
fi

case "$1" in
    error)
	sudo /opt/MegaRAID/MegaCli/MegaCli64 -PDList -aAll |egrep '^(Media|Other) Error Count:'|awk '{print $4}'|xargs|tr ' ' '+'|bc
        ;;
    online)
	sudo /opt/MegaRAID/MegaCli/MegaCli64 -PDList -aAll|egrep '^Firmware state: Online, Spun Up'|wc -l
   	;;
    
    temph)
    sudo /opt/MegaRAID/MegaCli/MegaCli64 -PDList -aAll|grep Temperature|sed -r 's/(.*:)([0-9]{1,3})(C.*)/\2/g'|sort -n|tail -n1
    ;;
    templ)
         /opt/MegaRAID/MegaCli/MegaCli64 -PDList -aAll|grep Temperature|sed -r 's/(.*:)([0-9]{1,3})(C.*)/\2/g'|sort -n|head -n1    
    ;;
    state)
    sudo /opt/MegaRAID/MegaCli/MegaCli64 -LDInfo -Lall -aALL |grep State|awk '{if($NF=="Optimal"){print 1}else{print 0}}' 
esac
