#!/bin/bash
#
#
[ $1 = "ESTABLISHED" ] && netstat -an|awk '/^tcp/{++A[$NF]}END{for(a in A)print a,A[a]}'|grep -v LISTEN >/tmp/netstat.log

cat /tmp/netstat.log
