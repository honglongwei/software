#!/bin/bash
#
#

IP=`/sbin/ifconfig|egrep -o 'addr:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'|cut -d: -f2|egrep -v '^127|^192'|xargs` 
Hostname=`/sbin/ifconfig|egrep -o 'addr:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}'|cut -d: -f2|egrep '^10'`

echo $IP|egrep -q '10.127.' && ServerIP=10.127.131.25
echo $IP|egrep -q '60.28.211|60.28.206' && ServerIP=
echo $IP|egrep -q '219.232|124.248' && ServerIP=10.16.42.109

yum install zabbix zabbix-agent zabbix-sender -y >/dev/null 2>&1 

echo 'ServerActive='$ServerIP >>/etc/zabbix/zabbix_agentd.conf
echo 'Server='$ServerIP >>/etc/zabbix/zabbix_agentd.conf
echo 'Hostname='$Hostname >>/etc/zabbix/zabbix_agentd.conf 
echo 'ListenIP='$Hostname >>/etc/zabbix/zabbix_agentd.conf
#/bin/cat sudoers >>/etc/sudoers
#rm sudoers zabbix_agentd.conf.tgz

/etc/init.d/zabbix-agent restart
